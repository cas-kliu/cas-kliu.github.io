#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <iostream>
#include <map>
#include <set>
#include <vector>
#include <string>
#include <ctime>
#include <fstream>
#include <cstring>
#include "experiment.h"

using namespace std;

typedef unsigned long long uint64_t;
typedef unsigned int uint32_t;

//[min, max)
double rand(double min, double max)
{
	return min + (max - min)*rand() / (RAND_MAX + 1.0);//ʹ��ϵͳĬ�ϵ����ֵ
}

//sqrare
double square(double a){
	return a * a;
}

double sigmod(double x){
	return 1.0 / (1.0 + exp(-1 * x));
}

//sigmod(x)�ĵ���
double sigmod_grad(double x){
	return x * (1 - x);
}

//reverse of sqrt 
double fast_rev_sqrt(double number)
{
	uint64_t i;
	double x2, y;
	x2 = number * 0.5;
	y = number;
	i = *(uint64_t *)&y;
	i = 0x5fe6eb50c7b537a9 - (i >> 1);
	y = *(double *)&i;
	y = y * (1.5 - (x2 * y * y));
	y = y * (1.5 - (x2 * y * y));
	return y;
}

//sqrt
double fast_sqrt(double number)
{
	return 1 / fast_rev_sqrt(number);
}

double norm_1(vector< double> &a){
	double norm = 0;
	for (unsigned i = 0; i < a.size(); i++)
		norm += abs(a[i]);
	return norm;
}

double norm_2(vector< double> &a){
	double norm = 0;
	for (unsigned i = 0; i < a.size(); i++)
		norm += (a[i] * a[i]);
	return fast_sqrt(norm);
}

double square_norm_2(vector<double> &a){
	double norm = 0;
	for (unsigned i = 0; i < a.size(); i++)
		norm += (a[i] * a[i]);
	return norm;
}

double inner(vector<double> &v1, vector<double> &v2){
	double value = 0;
	for (unsigned k = 0; k < v1.size(); k++)
		value += v1[k] * v2[k];
	return value;
}

vector<double> diff(vector<double> &v1, vector<double> &v2)
{
	vector<double> values(v1.size(), 0);
	for (unsigned k = 0; k < v1.size(); k++)
		values[k] = v1[k] - v2[k];
	return values;
}

vector<double> add(vector<double> &v1, vector<double> &v2)
{
	vector<double> values(v1.size(), 0);
	for (unsigned k = 0; k < v1.size(); k++)
		values[k] = v1[k] + v2[k];
	return values;
}


double L1_distance(vector<double> &v1, vector<double> &v2)
{
	double sum = 0;
	for (unsigned i = 0; i < v1.size(); i++)
		sum += fabs(v1[i] - v2[i]);
	return sum;
}

double L2_distance(vector<double> &v1, vector<double> &v2)
{
	double sum = 0;
	for (unsigned i = 0; i < v1.size(); i++)
		sum += square(v1[i] - v2[i]);
	return fast_sqrt(sum);
}

//the square of euclidean distance
double square_L2_distance(vector<double> &v1, vector<double> &v2)
{
	double sum = 0;
	for (unsigned i = 0; i < v1.size(); i++)
		sum += square(v1[i] - v2[i]);
	return sum;
}

//�õ�ent_vec������rel_vec��ʾ�ĳ�ƽ���ϵ�ӳ�� ent_vec - rel_vec'*ent_vec*rel_vec
vector<double> transHyper(vector<double> &ent_vec, vector<double> &rel_vec){
	int n = ent_vec.size();
	double inner = 0;
	for (int k = 0; k < n; k++)
		inner += ent_vec[k] * rel_vec[k];
	vector<double> values(n, 0);
	for (int k = 0; k < n; k++)
		values[k] = ent_vec[k] - inner * rel_vec[k];
	return values;
}

//normalize vector and matrix
void normalize(vector<double> &a)
{
	double sum = norm_2(a);
	if (sum > 0){
		for (unsigned i = 0; i < a.size(); i++)
			a[i] /= sum;
	}
}

//disorder a list randomly
void random_disorder_list(vector<unsigned> &list)
{
	unsigned size = list.size();
	for (unsigned i = 0; i < size; i++){
		unsigned index = rand() % (size - i) + i;
		if (index == i) continue;
		unsigned temp = list[i];
		list[i] = list[index];
		list[index] = temp;
	}
}

double max(vector<double> &v){
	double max = v[0];
	for (int i = 1; i < v.size(); i++)
		if (v[i] > max)
			max = v[i];
	return max;
}
double min(vector<double> &v){
	double min = v[0];
	for (int i = 1; i < v.size(); i++)
		if (v[i] < min)
			min = v[i];
	return min;
}

int ArgPos(char *str, int argc, char **argv) {
	int a;
	for (a = 1; a < argc; a++) if (!strcmp(str, argv[a])) {
		if (a == argc - 1) {
			printf("Argument missing for %s\n", str);
			exit(1);
		}
		return a;
	}
	return -1;
}

//�ַ����з�
vector<string> split(const string &text, const string &sep) {
	vector<string> tokens;
	int start = 0, end = 0;
	while ((end = text.find(sep, start)) != string::npos) {
		tokens.push_back(text.substr(start, end - start));
		start = end + 1;
	}
	tokens.push_back(text.substr(start));
	return tokens;
}
