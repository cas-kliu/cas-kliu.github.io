#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <iostream>
#include <fstream>
#include <map>
#include <set>
#include <vector>
#include <string>
#include <ctime>
#include <cstring>
#include <omp.h>
#include "experiment.h"

using namespace std;

#define E 2.718281828459
#define THREAD_NUM 64//�̸߳���

double EPSILON = 1e-6;

//string model_base_path = "G:/temp/TransX/fb15k/GEKL/";
string model_base_path = "";//currrent path
double loss_sum;

//global parameters
bool Neg_Scope = 1;
bool Neg_Method = 1;//bern��unif
int  Grad_Method = 1;
int  Batch_Size = 120;
int  Epoch_Size = 1500;

int    n = 50;
double rate = 0.001;
double margin = 2;
double para_min = 0.05;
double para_max = 5;

//global variables
vector<vector<double> > ent_mean, ent_vari, ent_mean_temp, ent_vari_temp; //��ֵ�ͷ���
vector<vector<double> > rel_mean, rel_vari, rel_mean_temp, rel_vari_temp;

//for AdaGrad gradient update
vector<vector<double> > ada_ent_mean, ada_ent_vari, ada_rel_mean, ada_rel_vari;

//origin data
long ent_num, rel_num, tri_num;
map<string, unsigned> ent2id, rel2id;
map<unsigned, string> id2ent, id2rel;

map<unsigned, map<unsigned, set<unsigned> > > sub_rel_objs;
map<unsigned, vector<unsigned> > rel_heads, rel_tails;
vector<double> head_num_per_tail, tail_num_per_head;//ƽ��ÿ��head�ж��ٸ�tail, ƽ��ÿ��tail�ж��ٸ�head

//train data
vector<triple> train_triples;

bool exist(triple tri){
	if (sub_rel_objs.count(tri.h) == 0)
		return false;
	if (sub_rel_objs[tri.h].count(tri.r) == 0)
		return false;
	if (sub_rel_objs[tri.h][tri.r].count(tri.t) == 0)
		return false;
	return true;
}

void saveModel(int epoch){
	string version = "unif";
	if (Neg_Method == 1) version = "bern";

	char dim_ch[5];
	sprintf(dim_ch, "%d", n);
	string dim_str = dim_ch;
	FILE* f1 = fopen(("ent2gau." + dim_str + "." + version).c_str(), "w");
	for (int kk = 0; kk < ent_num; kk++){
		for (int dim = 0; dim < n; dim++)
			fprintf(f1, "%.6lf\t", ent_mean[kk][dim]);
		fprintf(f1, "\n");
		for (int dim = 0; dim < n; dim++)
			fprintf(f1, "%.6lf\t", ent_vari[kk][dim]);
		fprintf(f1, "\n");
	}
	fclose(f1);
	FILE* f2 = fopen(("rel2gau." + dim_str + "." + version).c_str(), "w");
	for (int kk = 0; kk < rel_num; kk++){
		for (int dim = 0; dim < n; dim++)
			fprintf(f2, "%.6lf\t", rel_mean[kk][dim]);
		fprintf(f2, "\n");
		for (int dim = 0; dim < n; dim++)
			fprintf(f2, "%.6lf\t", rel_vari[kk][dim]);
		fprintf(f2, "\n");
	}
	fclose(f2);
}


void paramater_update(
	map<unsigned, vector<double> > &grad_temp,
	vector<vector<double> > &store_grad,
	vector<vector<double> > &ada_grad, bool is_vari){

	for (map<unsigned, vector<double> >::iterator it_inner = grad_temp.begin();
		it_inner != grad_temp.end(); it_inner++){
		int id = it_inner->first;
		for (int ii = 0; ii < n; ii++){
			double grad = it_inner->second[ii];
			if (Grad_Method == 2){
				ada_grad[id][ii] += square(grad);
				store_grad[id][ii] -= (grad * fast_rev_sqrt(ada_grad[id][ii] + EPSILON) * rate);
			}
			else
				store_grad[id][ii] -= (rate * grad);
		}
		if (is_vari){
			for (int ii = 0; ii < n; ii++){
				if (store_grad[id][ii] < para_min) store_grad[id][ii] = para_min;
				if (store_grad[id][ii] > para_max) store_grad[id][ii] = para_max;
			}
		}
		else
			normalize(store_grad[id]);
	}
}

void paramater_update(
	map<unsigned, vector<double> > &ent_mean_grad_temp,
	map<unsigned, vector<double> > &ent_vari_grad_temp,
	map<unsigned, vector<double> > &rel_mean_grad_temp,
	map<unsigned, vector<double> > &rel_vari_grad_temp){

	paramater_update(ent_mean_grad_temp, ent_mean, ada_ent_mean, false);
	paramater_update(ent_vari_grad_temp, ent_vari, ada_ent_vari, true);
	paramater_update(rel_mean_grad_temp, rel_mean, ada_rel_mean, false);
	paramater_update(rel_vari_grad_temp, rel_vari, ada_rel_vari, true);
}

double energyFunction(triple tri){
	double score = 0;
	for (int d = 0; d < n; d++){
		double ent_mean = ent_mean_temp[tri.h][d] - ent_mean_temp[tri.t][d];
		double ent_vari = ent_vari_temp[tri.h][d] + ent_vari_temp[tri.t][d];
		score += (ent_vari + square(ent_mean - rel_mean_temp[tri.r][d])) / rel_vari_temp[tri.r][d];
		score += (log(rel_vari_temp[tri.r][d]) - log(ent_vari));
	}
	return 0.5 * score;
}

double energyFunction(triple tri, vector<double> &ent_mean, vector<double> &ent_vari){
	double score = 0;
	for (int d = 0; d < n; d++){
		ent_mean[d] = ent_mean_temp[tri.h][d] - ent_mean_temp[tri.t][d];
		ent_vari[d] = ent_vari_temp[tri.h][d] + ent_vari_temp[tri.t][d];
		score += (ent_vari[d] + square(ent_mean[d] - rel_mean_temp[tri.r][d])) / rel_vari_temp[tri.r][d];
		score += (log(rel_vari_temp[tri.r][d]) - log(ent_vari[d]));
	}
	return 0.5 * score;
}

void trainTriple(triple pos_tri, triple neg_tri){
	vector<double> pos_ent_mean(n, 0), pos_ent_vari(n, 0);
	vector<double> pos_rel_mean = rel_mean_temp[pos_tri.r];
	vector<double> pos_rel_vari = rel_vari_temp[pos_tri.r];

	vector<double> neg_ent_mean(n, 0), neg_ent_vari(n, 0);
	vector<double> neg_rel_mean = rel_mean_temp[neg_tri.r];
	vector<double> neg_rel_vari = rel_vari_temp[neg_tri.r];

	double pos_energy = energyFunction(pos_tri, pos_ent_mean, pos_ent_vari);
	double neg_energy = energyFunction(neg_tri, neg_ent_mean, neg_ent_vari);
	if (pos_energy + margin <= neg_energy) return;
	loss_sum += (pos_energy + margin - neg_energy);

	map<unsigned, vector<double> > ent_mean_grad_temp, ent_vari_grad_temp;
	map<unsigned, vector<double> > rel_mean_grad_temp, rel_vari_grad_temp;
	ent_mean_grad_temp[pos_tri.h].resize(n);
	ent_vari_grad_temp[pos_tri.h].resize(n);
	ent_mean_grad_temp[pos_tri.t].resize(n);
	ent_vari_grad_temp[pos_tri.t].resize(n);
	rel_mean_grad_temp[pos_tri.r].resize(n);
	rel_vari_grad_temp[pos_tri.r].resize(n);

	ent_mean_grad_temp[neg_tri.h].resize(n);
	ent_vari_grad_temp[neg_tri.h].resize(n);
	ent_mean_grad_temp[neg_tri.t].resize(n);
	ent_vari_grad_temp[neg_tri.t].resize(n);
	rel_mean_grad_temp[neg_tri.r].resize(n);
	rel_vari_grad_temp[neg_tri.r].resize(n);

	//����ݶ�
	for (int dd = 0; dd < n; dd++){
		//pos����
		double pos_loss_temp = (pos_ent_mean[dd] - pos_rel_mean[dd]) / pos_rel_vari[dd];
		ent_mean_grad_temp[pos_tri.h][dd] += pos_loss_temp;
		ent_mean_grad_temp[pos_tri.t][dd] -= pos_loss_temp;
		rel_mean_grad_temp[pos_tri.r][dd] -= pos_loss_temp;

		ent_vari_grad_temp[pos_tri.h][dd] += (0.5 / pos_rel_vari[dd] - 0.5 / pos_ent_vari[dd]);
		ent_vari_grad_temp[pos_tri.t][dd] += (0.5 / pos_rel_vari[dd] - 0.5 / pos_ent_vari[dd]);

		double pos_rel_vari_temp = pos_ent_vari[dd] / square(pos_rel_vari[dd]) + square(pos_loss_temp);
		rel_vari_grad_temp[pos_tri.r][dd] -= 0.5 * pos_rel_vari_temp;
		rel_vari_grad_temp[pos_tri.r][dd] += 0.5 / pos_rel_vari[dd];

		//neg����
		double neg_loss_temp = (neg_ent_mean[dd] - neg_rel_mean[dd]) / neg_rel_vari[dd];
		ent_mean_grad_temp[neg_tri.h][dd] -= neg_loss_temp;
		ent_mean_grad_temp[neg_tri.t][dd] += neg_loss_temp;
		rel_mean_grad_temp[neg_tri.r][dd] += neg_loss_temp;

		ent_vari_grad_temp[neg_tri.h][dd] += (0.5 / neg_ent_vari[dd] - 0.5 / neg_rel_vari[dd]);
		ent_vari_grad_temp[neg_tri.t][dd] += (0.5 / neg_ent_vari[dd] - 0.5 / neg_rel_vari[dd]);

		double neg_rel_vari_temp = neg_ent_vari[dd] / square(neg_rel_vari[dd]) + square(neg_loss_temp);
		rel_vari_grad_temp[neg_tri.r][dd] += 0.5 * neg_rel_vari_temp;
		rel_vari_grad_temp[neg_tri.r][dd] -= 0.5 / neg_rel_vari[dd];
	}

#pragma omp critical
	{
		paramater_update(ent_mean_grad_temp, ent_vari_grad_temp, rel_mean_grad_temp, rel_vari_grad_temp);
	}
}



triple sampleNegTriple(triple pos_tri, bool is_head){
	triple neg_tri(pos_tri);
	bool in_relation = Neg_Scope;//�Ƿ��ڹ�ϵ��ѡ��
	int loop_size = 0;
	while (1){
		if (in_relation){
			if (is_head) neg_tri.h = rel_heads[neg_tri.r][rand() % rel_heads[neg_tri.r].size()];
			else neg_tri.t = rel_tails[neg_tri.r][rand() % rel_tails[neg_tri.r].size()];
		}
		else{
			if (is_head) neg_tri.h = rand() % ent_num;
			else neg_tri.t = rand() % ent_num;
		}
		if (!exist(neg_tri)) break;
		else if (loop_size++ > 10) in_relation = 0;//����10���ղ���������ȫ���г�
	}
	return neg_tri;
}

void trainTriple(triple pos_tri){
	int head_pro = 500;//ѡ�����head��Ϊ�������ĸ���
	if (Neg_Method){//bern
		double tph = tail_num_per_head[pos_tri.r];
		double hpt = head_num_per_tail[pos_tri.r];
		head_pro = 1000 * tph / (tph + hpt);
	}
	bool is_head = false;
	if ((rand() % 1000) < head_pro)
		is_head = true;
	trainTriple(pos_tri, sampleNegTriple(pos_tri, is_head));

	//�����ȡ��ϵ
	triple neg_tri(pos_tri);
	int loop_size = 0;
	while (1){
		neg_tri.r = rand() % rel_num;
		if (!exist(neg_tri)) break;
		else if (loop_size++ > 10) return;//��ȡ10�ζ����оͲ�ѵ����
	}
	trainTriple(pos_tri, neg_tri);
}

void trainTriple(){
	//random select batch��0 - tri_num
	vector<unsigned> batch_list(tri_num);
	for (int k = 0; k < tri_num; k++) batch_list[k] = k;
	random_disorder_list(batch_list);

	int batchs = tri_num / Batch_Size;//ÿ��batch��batch_size������

	for (int bat = 0; bat < batchs; bat++){
		int start = bat * Batch_Size;
		int end = (bat + 1) * Batch_Size;
		if (end > tri_num)
			end = tri_num;

		ent_mean_temp = ent_mean;
		ent_vari_temp = ent_vari;
		rel_mean_temp = rel_mean;
		rel_vari_temp = rel_vari;
#pragma omp parallel for schedule(dynamic) num_threads(THREAD_NUM)
		for (int index = start; index < end; index++)
			trainTriple(train_triples[batch_list[index]]);
	}
}

void trainModel(){
	time_t lt;

	for (int epoch = 0; epoch < Epoch_Size; epoch++){
		lt = time(NULL);
		cout << "*************************" << endl;
		cout << "epoch " << epoch << " begin at: " << ctime(&lt);
		double last_loss_sum = loss_sum;
		loss_sum = 0;

		trainTriple();//������Ԫ���Լ��

		lt = time(NULL);
		cout << "epoch " << epoch << " over  at: " << ctime(&lt);
		cout << "last loss sum : " << last_loss_sum << endl;
		cout << "this loss sum : " << loss_sum << endl;
		cout << "*************************" << endl;
		saveModel(epoch);
	}
}


void initModel(){
	ent_mean.resize(ent_num);
	ent_vari.resize(ent_num);
	for (int ee = 0; ee < ent_num; ee++){
		ent_mean[ee].resize(n);
		for (int dd = 0; dd < n; dd++)
			ent_mean[ee][dd] = rand(-1, 1);
		normalize(ent_mean[ee]);
		ent_vari[ee].resize(n, 0.33);
	}
	rel_mean.resize(rel_num);
	rel_vari.resize(rel_num);
	for (int rr = 0; rr < rel_num; rr++){
		rel_mean[rr].resize(n);
		for (int dd = 0; dd < n; dd++)
			rel_mean[rr][dd] = rand(-1, 1);
		normalize(rel_mean[rr]);
		rel_vari[rr].resize(n, 0.33);
	}
	cout << "init entity vector, relation means and variables are over" << endl;

	//or AdaGrad gradient update, sum of square of every steps
	ada_ent_mean.resize(ent_num);
	ada_ent_vari.resize(ent_num);
	for (int kk = 0; kk < ent_num; kk++){
		ada_ent_mean[kk].resize(n, 0);
		ada_ent_vari[kk].resize(n, 0);
	}
	ada_rel_mean.resize(rel_num);
	ada_rel_vari.resize(rel_num);
	for (int kk = 0; kk < rel_num; kk++){
		ada_rel_mean[kk].resize(n, 0);
		ada_rel_vari[kk].resize(n, 0);
	}
	cout << "init adagrad parameters are over" << endl;
}

void loadCorpus(){
	char buf[1000];
	int id;
	FILE *f_ent_id = fopen((model_base_path + "../data/entity2id.txt").c_str(), "r");
	while (fscanf(f_ent_id, "%s%d", buf, &id) == 2){
		string ent = buf; ent2id[ent] = id; id2ent[id] = ent; ent_num++;
	}
	fclose(f_ent_id);
	FILE *f_rel_id = fopen((model_base_path + "../data/relation2id.txt").c_str(), "r");
	while (fscanf(f_rel_id, "%s%d", buf, &id) == 2){
		string rel = buf; rel2id[rel] = id; id2rel[id] = rel; rel_num++;
	}
	fclose(f_rel_id);
	cout << "entity number = " << ent_num << endl;
	cout << "relation number = " << rel_num << endl;

	unsigned sub_id, rel_id, obj_id;
	string line;

	//��ȡ��Ԫ��
	ifstream f_kb((model_base_path + "../data/train.txt").c_str());
	map<unsigned, set<unsigned> > rel_heads_temp, rel_tails_temp;

	map<unsigned, map<unsigned, set<unsigned> > > relation_head_tails;//����ƽ��һ��head�ж��ٸ�tail
	map<unsigned, map<unsigned, set<unsigned> > > relation_tail_heads;//����ƽ��һ��tail�ж��ٸ�head

	while (getline(f_kb, line)){
		vector<string> terms = split(line, "\t");
		sub_id = ent2id[terms[0]]; rel_id = rel2id[terms[1]]; obj_id = ent2id[terms[2]];
		train_triples.push_back(triple(sub_id, rel_id, obj_id)); tri_num++;

		sub_rel_objs[sub_id][rel_id].insert(obj_id);
		rel_heads_temp[rel_id].insert(sub_id);
		rel_tails_temp[rel_id].insert(obj_id);
		relation_head_tails[rel_id][sub_id].insert(obj_id);
		relation_tail_heads[rel_id][obj_id].insert(sub_id);
	}
	f_kb.close();
	cout << "tripe number = " << tri_num << endl;

	for (map<unsigned, set<unsigned> >::iterator iter = rel_heads_temp.begin(); iter != rel_heads_temp.end(); iter++){
		unsigned rel_id = iter->first;
		for (set<unsigned>::iterator inner_iter = iter->second.begin(); inner_iter != iter->second.end(); inner_iter++)
			rel_heads[rel_id].push_back(*inner_iter);
	}
	for (map<unsigned, set<unsigned> >::iterator iter = rel_tails_temp.begin(); iter != rel_tails_temp.end(); iter++){
		unsigned rel_id = iter->first;
		for (set<unsigned>::iterator inner_iter = iter->second.begin(); inner_iter != iter->second.end(); inner_iter++)
			rel_tails[rel_id].push_back(*inner_iter);
	}

	tail_num_per_head.resize(rel_num);
	head_num_per_tail.resize(rel_num);
	for (int rel_id = 0; rel_id < rel_num; rel_id++){
		//����ƽ��һ��head�ж��ٸ�tail
		map<unsigned, set<unsigned> > tails_per_head = relation_head_tails[rel_id];
		unsigned head_number = 0, tail_count = 0;
		for (map<unsigned, set<unsigned> > ::iterator iter = tails_per_head.begin(); iter != tails_per_head.end(); iter++){
			if (iter->second.size() > 0){ head_number++; tail_count += iter->second.size(); }
		}
		tail_num_per_head[rel_id] = 1.0 * tail_count / head_number;
		//����ƽ��һ��tail�ж��ٸ�head
		map<unsigned, set<unsigned> > heads_per_tail = relation_tail_heads[rel_id];
		unsigned tail_number = 0, head_count = 0;
		for (map<unsigned, set<unsigned> > ::iterator iter = heads_per_tail.begin();
			iter != heads_per_tail.end(); iter++){
			if (iter->second.size() > 0){ tail_number++; head_count += iter->second.size(); }
		}
		head_num_per_tail[rel_id] = 1.0 * head_count / tail_number;
	}
}


int main(int argc, char**argv){
	int i;
	if ((i = ArgPos((char *)"-negScope", argc, argv)) > 0) Neg_Scope = atoi(argv[i + 1]);
	if ((i = ArgPos((char *)"-negMethod", argc, argv)) > 0) Neg_Method = atoi(argv[i + 1]);
	if ((i = ArgPos((char *)"-grad", argc, argv)) > 0) Grad_Method = atoi(argv[i + 1]);
	if ((i = ArgPos((char *)"-batch", argc, argv)) > 0) Batch_Size = atoi(argv[i + 1]);
	if ((i = ArgPos((char *)"-epoch", argc, argv)) > 0) Epoch_Size = atoi(argv[i + 1]);
	if ((i = ArgPos((char *)"-size", argc, argv)) > 0) n = atoi(argv[i + 1]);
	if ((i = ArgPos((char *)"-rate", argc, argv)) > 0) rate = atof(argv[i + 1]);
	if ((i = ArgPos((char *)"-margin", argc, argv)) > 0) margin = atof(argv[i + 1]);
	if ((i = ArgPos((char *)"-min", argc, argv)) > 0) para_min = atof(argv[i + 1]);
	if ((i = ArgPos((char *)"-max", argc, argv)) > 0) para_max = atof(argv[i + 1]);

	cout << "negative scope = " << Neg_Scope << endl;
	cout << "negative method = " << Neg_Method << endl;
	cout << "grad method = " << Grad_Method << endl;
	cout << "batch = " << Batch_Size << endl;
	cout << "epoch = " << Epoch_Size << endl;
	cout << "dim = " << n << endl;
	cout << "rate = " << rate << endl;
	cout << "margin = " << margin << endl;
	cout << "vari from = [" << para_min << "," << para_max << "]" << endl;

	time_t lt = time(NULL);
	cout << "begin at: " << ctime(&lt);
	loadCorpus();
	lt = time(NULL);
	cout << "prepare over at: " << ctime(&lt);
	initModel();
	lt = time(NULL);
	cout << "init net over at: " << ctime(&lt);
	trainModel();
	lt = time(NULL);
	cout << "train over at: " << ctime(&lt);

	return 1;
}